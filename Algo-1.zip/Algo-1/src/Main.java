import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		//step 1 . : take input array from the user 
		System.out.println("Enter the size of the array : ");
		
		Scanner sc = new Scanner(System.in);
		
		int size = sc.nextInt();
		int[] array = new int[size];

		System.out.println("Enter the elements : ");
		
		for(int i=0;i<size;i++)
		{
			array[i] = sc.nextInt();
		}
		
        //step2 : sort the array with mergesort
		
		MergeSort mergeSort = new MergeSort();
		mergeSort.sort(array,0,array.length-1);
		
		System.out.println("The array after sorting is : ");
		for(int i=0;i<size;i++)
		{
			System.out.print(array[i]+ " ");
		}
		
		System.out.println();
		
		
		//Step3 : rotate the array
		
		int midElement = array[array.length/2];
		
		ArrayRotation arrayRotation = new ArrayRotation();
		
		arrayRotation.leftRotate(array,midElement , array.length);
		
		System.out.println("The array after rotation is : ");
		for(int i=0;i<size;i++)
		{
			System.out.print(array[i]+ " ");
		}
		
		
		System.out.println();
		System.out.println();
		
		System.out.println("Enter the Key you want to search in the sorted and rotated array : ");
		int key = sc.nextInt();
		
		ModifiedBinarySearch pivotatedBinarySeacrh = new ModifiedBinarySearch();
		int index = pivotatedBinarySeacrh.pivotatedBinarySearch(array,array.length,key);
		
		System.out.print ("Key present at position : ");
		System.out.print(index);
		sc.close();
		

	}

}
