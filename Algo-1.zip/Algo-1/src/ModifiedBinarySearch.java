
public class ModifiedBinarySearch {

	public int pivotatedBinarySearch(int[] array, int length, int key) {

		int pivot = findPivotElement(array,0,length-1);
		
		//If we dint find a pivot ,then the array is not rotated at all
		if(pivot==-1)
		{
			return binarySeacrhImplementtation(array,0,length-1, key);
		}
		
		//if we found the pivot element , then first compare with pivot and then search in two sub arrays around the pivot
		else if(array[pivot]==key)
			return pivot;
		else if(array[0]<=key)
			return binarySeacrhImplementtation(array,0,pivot-1,key);
		return binarySeacrhImplementtation(array,pivot+1,length-1,key);
	}

	
	/*Standard binary search fucntion*/
	
	private int binarySeacrhImplementtation(int[] arr, int low, int high,int key) {
		if(high<low)
			return -1;
		
		int mid = (low+high)/2;
		
		if(key==arr[mid])
			return mid;
		else if(key>arr[mid])
			return binarySeacrhImplementtation(arr,(mid+1),high,key);
		return binarySeacrhImplementtation(arr,low,(mid-1),key);
	}


	//Function to get pivot , for array 3,4,5,6,1,2 it return 3 (index of 6)
	private int findPivotElement(int[] arr, int low, int high) {
		
		//3,4,5,6,1,2
		if(high<low)
		{
			return -1;
		}else if(high==low){
			return low;
		}
		
		int mid = (low+high)/2;
		
		if(mid<high && arr[mid]>arr[mid+1])
			return mid;
		else if(mid>low && arr[mid]<arr[mid-1])
			return mid-1;
		else if(arr[low]>=arr[mid])
			return findPivotElement(arr, low, mid-1);
		return findPivotElement(arr, mid+1, high);
		
	}

}
