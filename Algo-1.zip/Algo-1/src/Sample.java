
public class Sample {

//	Write a program to find the key element in sorted and rotated Array (from middle element its rotated)
	
	
	// Arr[] = {3,4,2,1,9,8,7}  //original array
	
	// ArrSorted[] = {1,2,3,4,7,8,9}  //sorted array
	
	// {9,1,2,3,4,7,8} //1 rotation
	// {8,9,1,2,3,4,7}
	// {7,8,9,1,2,3,4} //rotated array
		
	// ArrRotated[] = {7,8,9,1,2,3,4} //rotated array
	
	// Key = 8  //1
	
	
	//take input array from the user 
	//sort the array with mergesort
	//rotate the array
	//search to find the element.
	
}
