
public class ArrayRotation {

	
	// Function to left rotate array[] of length "size" by element elem.
	public void leftRotate(int[] array, int midElement, int size) {

		for(int i=0;i<midElement;i++)
		{
			leftRotatebyOne(array,size);
		}
		
		
	}

	private void leftRotatebyOne(int[] array, int size) {

		int temp;
		
		temp = array[0];
		for(int i=0;i<size-1;i++)
		{
			array[i] = array[i+1];
		}
		
		array[size-1] = temp;
	}
}