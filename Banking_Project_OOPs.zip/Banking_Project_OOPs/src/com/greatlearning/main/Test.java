package com.greatlearning.main;

public class Test {

	public static void main(String[] args) {
	
		System.out.println("Another main method");	
	}
}
