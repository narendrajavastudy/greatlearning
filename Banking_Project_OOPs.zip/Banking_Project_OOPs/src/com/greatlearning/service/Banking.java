package com.greatlearning.service;

import java.util.Scanner;

public class Banking {

	Scanner sc = new Scanner(System.in);

	OTPGenerator otpGenerator = new OTPGenerator();

	int bankBalance = 1000;

	public void deposit() {
		int amount;
		System.out.println("Please enter the amount you want to deposit");

		amount = sc.nextInt();

		if (amount > 0) {

			System.out.println("amount " + amount + " deposited successfully");

			bankBalance = bankBalance + amount;

			System.out.println("Updated Bank balance after deposit is : " + bankBalance);
		} else {
			System.out.println("Enter a correct amount !!");
		}
	}

	public void withdrawl() {
		int amount;

		System.out.println("Enter the amount you want to withdraw from the account :");
		amount = sc.nextInt();

		if (bankBalance - amount > 0) {
			System.out.println("Aount " + amount + " withdrawn successfully");

			bankBalance = bankBalance - amount;

			System.out.println("Updated Bank balance after withdrawl is : " + bankBalance);

		} else {
			System.out.println("Your account have insufficient balance");
		}
	}
	
	public void transfer()
	{
		int amount;
		int optUserEntered;
		int optGenerated;
		int bankAccountNo;
		
		System.out.println("Enter the OTP");
		
		optGenerated=otpGenerator.generateOTP();
		
		System.out.println("Generated OTP : " + optGenerated);
		
		optUserEntered = sc.nextInt();
		
		if(optUserEntered==optGenerated) {
			
			System.out.println("OTP verification is successful !!");
			
			System.out.println("Please enter the bank account number where you want to transfer the amount");
			
			bankAccountNo = sc.nextInt();
			
			System.out.println("Please enter the amount you want to transfer");
			
			amount = sc.nextInt();
			
			if(bankBalance-amount>0)
			{
				System.out.println("amount : " + amount + " transferred successfully to bank account "+bankAccountNo);
				
				bankBalance = bankBalance - amount;
				
				System.out.println("Updated Bank balance after transfer is : " + bankBalance);
				
			}else {
				System.out.println("Your account have insufficient Balance");
			}
			
		}else {
			System.out.println("Invalid OTP please try again !!");
		}
		
	}

}
