import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.Queue;

public class StackUsingQueue {

	Queue<Integer> queue;
	Queue<Integer> tempQueue;

	public StackUsingQueue() {
		queue = new LinkedList<Integer>();
		tempQueue = new LinkedList<Integer>();
	}

	public void push(int data) {
		/*
		 * if no element is present in queue then enque the new element into the queue
		 */

		if (queue.size() == 0)
			queue.add(data);
		else {
			/*
			 * if element are present in Q then deueue all the elements to tempQueue
			 * tempQueue
			 */
			int size = queue.size();

			for (int i = 0; i < size; i++)
				tempQueue.add(queue.remove());

			// enque the new element into the queue
			queue.add(data);

			// dequeue all the elements from temp queue tempQueue to queue

			for (int i = 0; i < size; i++)
				queue.add(tempQueue.remove());
		}
	}

	public int pop() {
		if (queue.size() == 0)
			throw new NoSuchElementException("Underflow Exception");

		return queue.remove();
	}

	public boolean isEmpty() {
		return queue.size() == 0;
	}

	public int getSize() {
		return queue.size();
	}

	public void display() {
		System.out.println("\nStack = ");
		int size = getSize();
		if (size == 0)
			System.out.println("Empty\n");
		else {
			Iterator itr = queue.iterator();
			while (itr.hasNext())
				System.out.println(itr.next() + " ");
			System.out.println();
		}
	}

}
