package com.greatlearning.service;

import java.util.Scanner;

import com.greatlearning.model.Employee;

public class DriverClass {
	
	
	static {
		System.out.println("Welcome to Email App !!");
		someMethod();
	}
	

	public static void main(String[] args) {
		
		Employee employee = new Employee("Rahul", "Gupta");
		
		CredentialsService credentialsService = new CredentialsService();
		
		String generatedEmail;
		char[] generatedpassword;
		
		
		System.out.println("Please enter the department from the following ");
		
		System.out.println("1. Technical");
		System.out.println("2. Admin");
		System.out.println("3. Human Resources");
		System.out.println("4. Legal");
		
		Scanner sc = new Scanner(System.in);
		
		int option = sc.nextInt();
		
		if(option==1)
		{
			generatedEmail = credentialsService.generateEmailAddress(employee.getFirstName().toLowerCase(), employee.getLastName().toLowerCase(), "tech");
			generatedpassword = credentialsService.generatePassword();
			credentialsService.showCredentials(employee, generatedEmail, generatedpassword);
		}else if(option==2)
		{
			generatedEmail = credentialsService.generateEmailAddress(employee.getFirstName().toLowerCase(), employee.getLastName().toLowerCase(), "adm");
			generatedpassword = credentialsService.generatePassword();
			credentialsService.showCredentials(employee, generatedEmail, generatedpassword);
		}else if(option==3)
		{
			generatedEmail = credentialsService.generateEmailAddress(employee.getFirstName().toLowerCase(), employee.getLastName().toLowerCase(), "hr");
			generatedpassword = credentialsService.generatePassword();
			credentialsService.showCredentials(employee, generatedEmail, generatedpassword);
		}else if(option==4)
		{
			generatedEmail = credentialsService.generateEmailAddress(employee.getFirstName().toLowerCase(), employee.getLastName().toLowerCase(), "lg");
			generatedpassword = credentialsService.generatePassword();
			credentialsService.showCredentials(employee, generatedEmail, generatedpassword);
		}else {
			System.out.println("Enter a valid option !!");
		}
		
		sc.close();

	}


	private static void someMethod() {
		System.out.println("From some method !!");
	}

}
