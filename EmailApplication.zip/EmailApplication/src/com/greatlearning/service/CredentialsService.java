package com.greatlearning.service;

import java.util.Random;

import com.greatlearning.model.Employee;

public class CredentialsService {
	
	
	public char[] generatePassword()
	{
		char[] password = new char[8];

		String capitalLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String smallLetters = "abcdefghijklmnopqrstuvwxyz";
		String numbers = "0123456789";
		String specialCharacters = "!@#$%^&*_=+-/.?<>";

		String values = capitalLetters + smallLetters + numbers + specialCharacters;

		// Using random method

		Random random = new Random();

		password[0] = capitalLetters.charAt(random.nextInt(capitalLetters.length()));
		password[1] = smallLetters.charAt(random.nextInt(smallLetters.length()));
		password[2] = numbers.charAt(random.nextInt(numbers.length()));
		password[3] = specialCharacters.charAt(random.nextInt(specialCharacters.length()));
		
		for (int i = 4; i < 8; i++) {
			password[i] = values.charAt(random.nextInt(values.length()));
		}
		return password;
	}
	
	
	public String generateEmailAddress(String firstName , String lastName , String department)
	{
		StringBuffer sb = new StringBuffer();
		sb.append(firstName);
		sb.append(lastName);
		sb.append("@");
		sb.append(department);
		sb.append(".abc.com");
		
		return sb.toString();
	}
	
	
	public void showCredentials(Employee employee,String email,char[] generatedpassowrd) {
		System.out.println("Dear "+employee.getFirstName() + " your generated credentials are as follows");
		System.out.println("Email ---> 1" + new String(generatedpassowrd));
		//System.out.println(generatedpassowrd);
	}
}
