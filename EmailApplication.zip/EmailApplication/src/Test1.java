
public class Test1 {

	public static void main(String[] args) {
		
		int str = 123;
		char ch = 'A';
		
		int str1 = str+ch;
		
		
		
		int i = 20;
		if(i==10)
		{
			System.out.println("100");
		}
		//else if(i==10)
		
		else
		{
			if(i==10)
			System.out.println("200");
		}
	}
		

}
